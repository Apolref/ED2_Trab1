#include <stdio.h>
#include <stdlib.h>
#include "matriz.h"
#include "Ordena.h"


#ifndef T1TEMP_CONTAGEM_INTERSECOES_H
#define T1TEMP_CONTAGEM_INTERSECOES_H

#endif //T1TEMP_CONTAGEM_INTERSECOES_H

void contagem_intersecoes(FILE *arq_A, FILE *arq_B, int nA, int nB, FILE *arquivo_saida);