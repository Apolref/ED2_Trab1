# ED2_Trab1 v1.0
Essa é a primeira compilação completa do código, ela apresenta bugs. Não é funcional!
"Trabalho 1 da disciplina de Estrutura de Dados 2"
