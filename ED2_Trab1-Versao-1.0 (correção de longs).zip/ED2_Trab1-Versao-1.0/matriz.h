#include <stdio.h>
#include <stdlib.h>


#ifndef T1TEMP_MATRIZ_H
#define T1TEMP_MATRIZ_H

#endif //T1TEMP_MATRIZ_H


long **Alocar_matriz(int m, int n);
long **Liberar_matriz (int m, int n, long **v);