#include <stdio.h>
#include <stdlib.h>
#include "matriz.h"


#ifndef T1TEMP_ORDENA_H
#define T1TEMP_ORDENA_H

#endif //T1TEMP_ORDENA_H

void OrdenaDigitos(int n, long **A, int posicao);
void OrdenaNumeros(int n,long **A);
